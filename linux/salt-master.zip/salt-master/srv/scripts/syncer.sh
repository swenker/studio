#!/bin/sh
# CN Azure Prod, CN Azure Staging, global Azure
jumpboxen=( pe-mmi.chinacloudapp.cn pn-mmi.chinacloudapp.cn staging-mmi.chinacloudapp.cn dev-mmi.chinacloudapp.cn ind-p3-mmi.cloudapp.net )
for jb in "${jumpboxen[@]}" 
do
  ssh -t $jb " ssh -t salt sudo /root/AzureChina/scripts/local_git_pull.sh"
  echo "Done with $jb"
  echo "----------------------"
done
