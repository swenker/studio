# Author:       cloudsre@motorola.com
# Purpose:      Copy 1 blob from a storage account in Azure to another
# Requirements: This workstation must have the Azure powershell installed and 
#               configured with the account. 

### Start configuration area ###
# Subscription
$SubscriptionName="A_020";
$SubscriptionID="b1e2a52f-a415-47d4-b378-f765f287e75c";

# Storage (specify your storage account names)
$SrcStorageAccount="store03mmi";
$VHDContainerName= "vhds";

$DestStorageAccount="store01devmmi";
$DestContainerName= "vhds";
 
# Find out t e actual name of the VHD by looking in your storage account/container
$SrcImageVHD= "I-JETTY-S-N-os-2015-01-14.vhd";
$DestImageVHD="I-JETTY-S-N-pre-dev.vhd";
### End configuration Area

# Pick the current subscription
Select-AzureSubscription -SubscriptionName $SubscriptionName;
"Subscription selected"
# Context to source storage
$SrcStgKey = (Get-AzureStorageKey -StorageAccountName $SrcStorageAccount).Primary;
$SrcStorageContext=New-AzureStorageContext -StorageAccountName $SrcStorageAccount -endpoint "core.chinacloudapi.cn" -StorageAccountKey $SrcStgKey -Protocol Https;

# Context to destination storage
$DestStgKey = (Get-AzureStorageKey -StorageAccountName $DestStorageAccount).Primary;
$DestStorageContext=New-AzureStorageContext -StorageAccountName $DestStorageAccount -endpoint "core.chinacloudapi.cn" -StorageAccountKey $DestStgKey -Protocol Https;
"Contexts received. Starting copy"


# Copy image blob from source storage to dest storage; note that initial image blob is 
# in "vhds" container not "images", even though going forward, we want to use "images"
$ImageBlob=Start-CopyAzureStorageBlob `
    -SrcContext $SrcStorageContext -SrcBlob $SrcImageVHD `
    -DestContext $DestStorageContext -DestBlob $DestImageVHD `
    -SrcContainer $VHDContainerName `
    -DestContainer $DestContainerName

# Wait for copy to complete
$ImageBlob | Get-AzureStorageBlobCopyState -WaitForComplete;
