#!/usr/bin/python
# -*- coding: utf-8 -*-
import re, getopt, sys
import codecs


#old_host_file = "/Users/mheck/github-mmi-mheck/AzureChina/salt/fHosts/hosts-production"

#get command line arguments


#powershell_file = ''
#new_host_file = ''

def get_args(argv):
    #bash_command = "esxcli --server vcenter001-ops.va3.svcmot.com --username " + user + " --password " + pw + " --vihost " + esx + " storage nfs list "
    #bash_command = "ls -la"
    powershell_file = ''
    new_host_file = ''
    #global powershell_file
    #global new_host_file

    try:
        opts, args = getopt.getopt(argv,"hf:o:",["help=","file=","output="])
    except getopt.GetoptError:
        print 'give_me_hosts.py -f <input_file> -o <hosts_file_output>'
        sys.exit(2)
    for opt, arg in opts:
        if opt == '-h':
            print 'give_me_hosts.py -f <input_file> -o <hosts_file_output>'
            sys.exit()
        elif opt in ("-f", "--file"):
            powershell_file = arg
        elif opt in ("-o", "--output"):
            new_host_file = arg
    return powershell_file, new_host_file

    

     



def get_your_hosts():

    files = get_args(sys.argv[1:])

    powershell_file = files[0]
    new_host_file = files[1]
    #Open file with unicode support
    hosts_in = codecs.open(powershell_file, encoding='utf-16', mode="r")

    print hosts_in
    """
    for line in hosts_in:
        print line,
        """

    #print "file type %s " % mimetypes.guess_extension(powershell_file)
    hosts_in.seek(0)
    #matches = re.findall('.*', hosts_in.read())
    matches = re.findall('\s+\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}.*', hosts_in.read())
    hosts_in.close()
    for line in matches:
        print "This '%s'\n" % line,

    matches.sort()

    hosts_out = open(new_host_file, "w+")

    print hosts_out
    #regex match for dev
    #dev = re.compile(".+-d-.+")

    #regex match for staging
    #staging = re.compile(".+-s-.+")

    #write out localhost config
    hosts_out.write("#\n" + "# This file is managed by salt. Any manual changes will be discarded.\n")
    hosts_out.write("127.0.0.1\t  localhost localhost.localdomain localhost4 localhost4.localdomain4\n")
    hosts_out.write("::1\t\t  localhost localhost.localdomain localhost6 localhost6.localdomain6\n")

    for match in matches:
        #print "This is where the file is" + hosts_
        #print match
        ip_addr = match.split()[0]
        host = match.split()[2]

        print "ip %s host %s" % (ip_addr, host)
        cas_match = re.match('^(cas[\d]{2}-in-p)([en]-mmi)', host)
        #if re.search(r'.+-d-.+',host) or re.search(r'-qa3$',host):
        #if re.search(dev, host) or re.search(r'-qa3$',host):
            #print host + " Dev, I found you"
        #elif re.search(staging, host) or re.search(r'-stg$', host):
            #print host + " a staging"
        #make sure host is within prod subnets 10.0.8.0/20 and 10.0.16.0/20 for north and east regions
        if re.search('^10\.0\.\d{1,3}\.\d{1,3}', ip_addr) \
            and ((16 <= ip_addr.split(".")[2] >= 31) or (8 <= ip_addr.split(".")[2] >= 12)):
            #print match + " you got the right one baby"
            #if host is salt ignore it and do them at the end.
            if host == 'salt01-p-mmi' or host == 'salt51':
                pass
                #print "ignoring salt " + host
            #add alias for active db in db01-02
            elif host == 'db01-p-mmi':
                write_out_h(hosts_out, ip_addr, host, "db-p-mmi")
            #elif host == 'salt02-pn-mmi':
                #write_out_h(hosts_out, ip_addr, host, "db-p-mmi")
            elif cas_match:
                hosts_out.write("%s\t%s\t%s-%s\n" \
                    % (ip_addr, host, cas_match.group(1), cas_match.group(2)))
            else:
                write_out_h(hosts_out, ip_addr, host)
    """
    for x,y in enumerate(matches):
        print "host %s ip %s" % (x,y)
    """

    #write out salt configuration specific to regions
    salt_n_indic = [i for i, x in enumerate(matches) if x.split()[2] == 'salt01-p-mmi']
    salt_e_indic = [i for i, x in enumerate(matches) if x.split()[2] == 'salt51']
    print "salt north  indiced %s" % salt_n_indic
    print "salt east  indiced %s" % salt_e_indic

    salt_north = matches[salt_n_indic[0]]
    salt_east = matches[salt_e_indic[0]]
    #now that we've found the salt north and east records, write them out to file with jinja context specific to moto-cloud grain
    #please note this may change with merging salt repos across the environments
    hosts_out.write("{%   if   grains['moto-cloud'] == 'cn-azure-production-north': %}\n")
    write_out_h(hosts_out,salt_north.split()[2], salt_north.split()[0], "salt", "smtp")
    #hosts_out.write(salt_north.split()[1] + "\t  " + salt_north.split()[0] + " salt smtp\n")
    #hosts_out.write(salt_east.split()[1] + "\t  " + salt_east.split()[0] + "\n")
    write_out_h(hosts_out, salt_east.split()[2], salt_east.split()[0])
    hosts_out.write("{%   elif grains['moto-cloud'] == 'cn-azure-production-east': %}\n")
    write_out_h(hosts_out, salt_north.split()[2], salt_north.split()[0], "smtp")
    #hosts_out.write(salt_north.split()[1] + "\t  " + salt_north.split()[0] + " smtp\n")
    #hosts_out.write(salt_east.split()[1] + "\t  " + salt_east.split()[0] + " salt\n")
    write_out_h(hosts_out,salt_east.split()[2],salt_east.split()[0],"salt")
    hosts_out.write("{% endif %}\n")

    #add more entries not given in powershell script
    hosts_out.write("#Entries below are not captured in powershell automation\n")
    write_out_h(hosts_out, "111.221.92.154", "moto-cds-sg")
    hosts_out.write("#CCS Internal Azure LB\n")
    write_out_h(hosts_out, "10.0.16.91", "lb01-ccs-p-mmi2", "lb01-ccs-p-mmi")
    write_out_h(hosts_out, "10.0.16.90", "lb02-ccs-p-mmi2", "lb02-ccs-p-mmi")
    write_out_h(hosts_out, "10.0.8.91", "lb51-ccs-p-mmi2", "lb51-ccs-p-mmi")
    write_out_h(hosts_out, "10.0.8.21", "lb52-ccs-p-mmi2", "lb52-ccs-p-mmi")
    write_out_h(hosts_out, "139.219.131.40", "ind-pe-mmi")
    hosts_out.write("#OTA Internal Azure LB\n")
    write_out_h(hosts_out, "10.0.16.5", "lb02-ota-p-mmi2", "lb02-ota-p-mmi")
    write_out_h(hosts_out, "10.0.8.17", "lb52-ota-p-mmi2", "lb52-ota-p-mmi")
    write_out_h(hosts_out, "10.0.11.17", "gss1-pe-mmi", "gss1-pe-mmi.chinacloudapp.cn")


    #close the new hosts file
    hosts_out.close()

def write_out_h(file_obj, *argv):
    for arg in argv:
        file_obj.write("%s\t" % (arg))
    file_obj.write("\n")


#compare generated host to existing host file.
def compare_hosts_files(old_host_file, new_host_file):
    old_host = open(old_host_file,"r")
    new_host = open(new_host_file, "r")

    old_dict = load_hosts_dict(old_host)
    new_dict = load_hosts_dict(new_host)

    #Close both files
    old_host.close()
    new_host.close()
    """
    print "OLD HOST"
    for key,value in old_dict.iteritems():
        print "This is key " + key + "\n"
        print "This is value " + value + "\n"

    print "NEW HOST"
    for key,value in new_dict.iteritems():
        print "This is key " + key + "\n"
        print "This is value " + value + "\n"
    """

    for key,value in old_dict.iteritems():
        if key not in new_dict:
            print "host %s ip %s is not in new hosts file" % (key,old_dict[key])

    #Close both files
    old_host.close()
    new_host.close()

def load_hosts_dict(file_obj):
    host_dict = {}
    for line in file_obj:
        ip_host_str = re.match(r'^(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})\W+([\w-]+)',line)
        if ip_host_str:
            host_dict[str(ip_host_str.group(2))] = ip_host_str.group(1)
            #print "IP " + str(ip_host_str.group(1)) + " HOST " + ip_host_str.group(2)

    return host_dict


    

#compare_hosts_files(old_host_file, new_host_file)

#get command-line arguments






get_your_hosts()

"""

            if host == 'salt01-p-mmi':
                hosts_out.write("{%   if   grains['moto-cloud'] == 'cn-azure-production-north': %}\n")
                hosts_out.write(ip + "\t  " + host + " salt smtp\n")
                
            elif host == 'salt51':
                hosts_out.write("{%   elif grains['moto-cloud'] == 'cn-azure-production-east': %}")
                hosts_out.write(ip +"\t  " + host + " salt\n")
            else:
                hosts_out.write(ip_addr + "\t  " + host + "\n")

   """ 
