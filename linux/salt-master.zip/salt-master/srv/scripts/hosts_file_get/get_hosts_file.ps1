# Author:       mheck@motorola.com
# Purpose:      Get list of private IPs in order to generate host file.
# Requirements: This workstation must have the Azure powershell installed and 
#               configured with the account. 



### Start configuration area ###
# Subscription
$SubscriptionName="A_020";
$SubscriptionID="b1e2a52f-a415-47d4-b378-f765f287e75c";

#$service="pn-mmi"

#$VM="adm01-ops-p-mmi"


# Pick the current subscription
Select-AzureSubscription -SubscriptionName $SubscriptionName;

#Get-AzureVM -ServiceName $service -Name $VM


Get-AzureVM | Get-AzureVM | Select-Object *IP*, Name | Format-Table –AutoSize

#Get-AzureVNetConfig
