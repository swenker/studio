#!/bin/bash

# run git pull in defined local directories
mydirs=( "/root/AzureChina" )
for i in "${mydirs[@]}"
do
	echo "--------------------" 
	echo $i
	cd ${i}
	git pull
done; echo "--------------------"
