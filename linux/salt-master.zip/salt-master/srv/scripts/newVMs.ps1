# Author:  cloudsre@motorola.com
# Purpose: Create new VMs in Azure
# Requirements: This must be run on a windows work station.
#               The workstation need the Azure powershell installed and 
#               configured for the Azure accout. Link below
#               http://azure.microsoft.com/en-us/documentation/articles/install-configure-powershell/
# Other Notes:
#              This CANNOT be used for the first VM inside a new cloud 
#              service or the VMs might not end up in the proper vnet.
#              The first VM in a cloud service should be made manually.
#              If only 1 or 2 VMs are needed, it might be easier to use the
#              web site to make them.

# Naming details
# hostname = hostnamePrefix + Number + hostnameSuffix
$startingNumber=1
$endingNumber=2
$hostnamePrefix="mmc"
$hostnameSuffix="-ntf-d-mmi"
$vmSize = "A5"
$imageName="i-jetty-d"
# What's the default username? Set the p
$un = 'azureuser'
$pwd
$flgChina=$TRUE
if ( $flgChina )
{
 
    $pwd = ''
    #Set-AzureSubscription 'A_020'  -SubscriptionId "b1e2a52f-a415-47d4-b378-f765f287e75c"
    $sStorageAccount="store01devmmi"
    $sCloudService="dev-mmi"
    $sURLSuffix="blob.core.chinacloudapi.cn"
    $sDataCenter="China North"


} else {
    $pwd = ''
    Set-AzureSubscription 'Pay-As-You-Go' -SubscriptionId "6d1fadd8-05a4-4b22-9dec-5e7ca49f8674"
    $sStorageAccount="indp3mmi"
    $sCloudService="ind-p3-mmi"
    $sURLSuffix="blob.core.windows.net"
    $sDataCenter="Southeast Asia"

}

### END CONFIGURATION AREA ####

$i=$startingNumber
$j=$endingNumber + 1
while( $i -lt $j )
{
 $image=$imageName
 "Image used is $imageName"
 $shostname= $hostnamePrefix + $i + $hostnameSuffix
 $vm1 = New-AzureVMConfig -Name $shostname -InstanceSize $vmSize -Image $image -MediaLocation "https://$sStorageAccount.blob.core.chinacloudapi.cn/vhds/$shostname.vhd"
 "https://$sStorageAccount.$sURLSuffix/vhds/$shostname.vhd"
 $vm1 | Add-AzureProvisioningConfig -Linux -LinuxUser $un -Password $pwd -NoSSHEndpoint
 $vm1 | New-AzureVM -ServiceName $sCloudService -Location $sDataCenter -VNetName vnet-east-p-mmi
 $i++
}
