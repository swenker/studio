#!/bin/sh
username=$1
if [ ! -d /home/$username/AzureChina ]
then
	echo Bad source directory. Exiting.
	exit
fi
# Do a local sync on the puppet server
ssh -t salt sudo rsync -azv --no-owner /home/$username/AzureChina/ /srv
