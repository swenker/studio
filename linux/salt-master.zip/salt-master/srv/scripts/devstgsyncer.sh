#!/bin/sh
if [ $1 ]
then
	gceDir=$1
else
	echo Where is your local SaltStack repo for CN Azure Pre-Prod?
	read gceDir
fi
if [ ! -d $gceDir ]
then
	echo I cannot find the local SaltStack repo for CN Azure Pre-Prod at $gceDir. Exiting.
	exit
fi
# CN Azure Pre-Prod, CN Azure Staging
jumpboxen=( staging-mmi.chinacloudapp.cn dev-mmi.chinacloudapp.cn )
for jb in "${jumpboxen[@]}" 
do
	echo == $jb ==
	# Upload to Jumpbox
	rsync -azv --exclude '.git' -e ssh $gceDir/ $jb:~/cn-azure-salt
	echo === synced to jumpbox
	# Move from jumpbox to puppet server
	ssh -t $jb rsync -azv -e ssh \~/cn-azure-salt salt:~/
	echo === synced to PM user
	# rsync to puppet install dir
	ssh -t $jb \~/cn-azure-salt/scripts/finalRsync.sh $USER
	echo =======
done
