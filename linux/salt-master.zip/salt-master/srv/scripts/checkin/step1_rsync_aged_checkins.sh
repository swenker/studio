#!/bin/bash
#migrate checkin data using rsync to an ebs volume
month=$1
echo "First pass $month"
for i in {1..8}
do
    rsync -avsShHP  /mnt/gluster_share_ccs_store/netapp0$i/handset_checkin/outgoing/2015-$month* /mnt/aged_checkin_data/month$month/netapp0$i/handset_checkin/outgoing
done

echo "Starting second pass"

for i in {1..8}
do
    rsync -avsShHP  /mnt/gluster_share_ccs_store/netapp0$i/handset_checkin/outgoing/2015-$month* /mnt/aged_checkin_data/month$month/netapp0$i/handset_checkin/outgoing
done

echo "Check hashes"
for i in {1..8}
do
    rsync -cavsShHP  /mnt/gluster_share_ccs_store/netapp0$i/handset_checkin/outgoing/2015-$month* /mnt/aged_checkin_data/month$month/netapp0$i/handset_checkin/outgoing
done