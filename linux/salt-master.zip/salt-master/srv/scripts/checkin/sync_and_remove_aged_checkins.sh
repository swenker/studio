#!/bin/bash
#migrate checkin data using rsync to an ebs volume
month=$1

function exit_code_check (){

	if [ $? -ne 0 ]
	then
		echo "Problems with previous rsync"
		exit 1
	else
		echo "Rsync finished for netapp$i"
	fi
}

echo "First pass $month"
for i in {1..8}
do
    rsync -avsShHP  /mnt/gluster_share_ccs_store/netapp0$i/handset_checkin/outgoing/2015-$month* /mnt/aged_checkin_data/month$month/netapp0$i/handset_checkin/outgoing
    exit_code_check "${?}" "${i}"
done

echo "Check hashes"
for i in {1..8}
do
    rsync -cavsShHP  /mnt/gluster_share_ccs_store/netapp0$i/handset_checkin/outgoing/2015-$month* /mnt/aged_checkin_data/month$month/netapp0$i/handset_checkin/outgoing
    exit_code_check "${?}" "${i}"
done

echo "Removing synced source files for 2015-$month"
for i in {1..8}
do
	printf "\n\n----------------------------------------\n"
	printf "Removing synced files from folder netapp $i of 8"
	printf "\n----------------------------------------\n\n"
    rsync -avsShHP --remove-source-files  /mnt/gluster_share_ccs_store/netapp0$i/handset_checkin/outgoing/2015-$month* /mnt/aged_checkin_data/month$month/netapp0$i/handset_checkin/outgoing
    exit_code_check "${?}" "${i}"
done


#Remove empty directories starting from the bottom of the dir tree with -depth

for i in {1..8}
do
	printf "\n\n----------------------------------------\n"
	printf "Removing empty dirs from folder netapp $i of 8"
	printf "\n----------------------------------------\n\n"
	find /mnt/gluster_share_ccs_store/netapp0$i/handset_checkin/outgoing/2015-$month* -depth  -exec rmdir {} \;
	exit_code_check "${?}" "${i}"
done

echo "Finished removing files and folders for month $month"
exit 0