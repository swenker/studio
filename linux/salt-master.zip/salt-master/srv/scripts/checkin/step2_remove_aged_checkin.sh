#!/bin/bash
#delete files if they're present on synced source
#PLEASE RUN checkin_aged_rsync.sh FIRST!!
month=$1
echo "Removing source files for $month"
for i in {1..8}
do
	printf "\n\n----------------------------------------\n"
	printf "Removing synced files from folder netapp $i of 8"
	printf "\n----------------------------------------\n\n"
    	rsync -avsShHP --remove-source-files  /mnt/gluster_share_ccs_store/netapp0$i/handset_checkin/outgoing/2015-$month* /mnt/aged_checkin_data/month$month/netapp0$i/handset_checkin/outgoing
done


#Remove empty directories starting from the bottom of the dir tree with -depth

for i in {1..8}
do
	printf "\n\n----------------------------------------\n"
	printf "Removing empty dirs from folder netapp $i of 8"
	printf "\n----------------------------------------\n\n"
	find /mnt/gluster_share_ccs_store/netapp0$i/handset_checkin/outgoing/2015-$month* -depth  -exec rmdir {} \;
done

echo "Finished removing files and folders for month $month"